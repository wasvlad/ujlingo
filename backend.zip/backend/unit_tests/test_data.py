class TestData:
    class User:
        email = "test@example.com"
        password = "ks!flDSf43wd"
        name = "Test"
        surname = "User"
